package com.example.appcanciones

data class Cancion(
    val titulo: String,
    val archivo: Int
)