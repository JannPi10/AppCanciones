package com.example.appcanciones

import android.media.MediaPlayer
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CancionesActivity : AppCompatActivity() {

    private lateinit var rvCanciones: RecyclerView
    private lateinit var btnRandom: Button
    private lateinit var btnStopRandom: Button
    private lateinit var adapter: CancionAdapter
    private lateinit var listaCanciones: List<Cancion>
    private var mediaPlayer: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_canciones)

        btnStopRandom = findViewById(R.id.btnStopRandom)
        rvCanciones = findViewById(R.id.rvCanciones)
        btnRandom = findViewById(R.id.btnRandom)

        listaCanciones = listOf(
            Cancion("AURORA", R.raw.aurora),
            Cancion("Perdido en tus ojos", R.raw.perdido),
            Cancion("REINA", R.raw.reina),
            Cancion("Otra Vida", R.raw.otravida),
            Cancion("DETRAS DE TU ALMA", R.raw.detras),
            Cancion("EL ULTIMO BESO", R.raw.ultimo)
        )

        adapter = CancionAdapter(this, listaCanciones)
        rvCanciones.layoutManager = LinearLayoutManager(this)
        rvCanciones.adapter = adapter

        btnRandom.setOnClickListener {
            mediaPlayer?.stop()
            mediaPlayer?.release() /**esto lo hacemos para detener alguna cancion si es que hay alguna sonando*/
            val index = encontrarPosicionDePrimo(3)
            mediaPlayer = MediaPlayer.create(this, listaCanciones[index].archivo).apply {
                start()
            }
            /**mediaPlayer.start()*/
            /** Aca iniciamos una nueva cancion aleatoria*/
        }

        btnStopRandom.setOnClickListener {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
            /** avisamos que la cancion se detuvo*/
            Toast.makeText(this, "Reproducción detenida", Toast.LENGTH_SHORT).show()
        }
    }

    private fun encontrarPosicionDePrimo(n: Int): Int {
        var contador = 0
        var numero = 2
        while (true) {
            if (esPrimo(numero)) {
                contador++
                if (contador == n) return numero - 1
            }
            numero++
        }
    }

    private fun esPrimo(num: Int): Boolean {
        if (num < 2) return false
        for (i in 2 until num) {
            if (num % i == 0) return false
        }
        return true
    }
}